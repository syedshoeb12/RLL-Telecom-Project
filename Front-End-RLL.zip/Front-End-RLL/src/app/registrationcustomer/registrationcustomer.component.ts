import { Component, OnInit } from '@angular/core';
import { CustService } from '../cust-service.service';

@Component({
  selector: 'app-registrationcustomer',
  templateUrl: './registrationcustomer.component.html',
  styleUrls: ['./registrationcustomer.component.css']
})
export class RegistrationcustomerComponent implements OnInit {

  create : any;

  constructor(private _custService : CustService){}
  register(create:any){
this._custService.create(create.value).subscribe(

);
alert('Registration  Successfull')
  }

  ngOnInit(): void {
  }

}