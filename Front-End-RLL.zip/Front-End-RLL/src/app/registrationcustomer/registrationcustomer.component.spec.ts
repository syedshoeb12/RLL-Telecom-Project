import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationcustomerComponent } from './registrationcustomer.component';

describe('RegistrationcustomerComponent', () => {
  let component: RegistrationcustomerComponent;
  let fixture: ComponentFixture<RegistrationcustomerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegistrationcustomerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationcustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
