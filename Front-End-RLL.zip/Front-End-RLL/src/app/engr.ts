export class Engr {

    public engr_ID:number;
    public engrname:string;
    public pincode:number;
    public mobileno: number;
 
}
