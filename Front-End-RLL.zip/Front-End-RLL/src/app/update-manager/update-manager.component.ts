import { Component, OnInit } from '@angular/core';
import { Mgr } from '../mgr';
import { MgrService } from '../mgr.service';

@Component({
  selector: 'app-update-manager',
  templateUrl: './update-manager.component.html',
  styleUrls: ['./update-manager.component.css']
})
export class UpdateManagerComponent implements OnInit {


  mgr :Mgr[];
  mgrDetails = null as any;
  mgrToUpdate = {
    mgr_ID:"",
    mgrname:"",
    pincode:"",
    mobileno:""
  };
  managerToUpdate:any;

  constructor(private mgrservice: MgrService) {
    this.showmgr();
  }
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  showmgr() {
    this.mgrservice.showmgr().subscribe(
      (resp: any) => {
        console.log(resp);
        this.mgr= resp;
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  delteUser(mgr_ID: any) {
    this.mgrservice.deleteUser(mgr_ID).subscribe(
      (resp: any) => {
        console.log(resp);
        this.showmgr();
        alert('Data Deleted Successfully')
      },
      (err: any) => {
        console.log(err);
      }
     
    );
  }

  edit(manager: any){
    this.managerToUpdate = manager;
  }

  updatemanager(){
    this.mgrservice.updatemanager(this.managerToUpdate).subscribe(
      (resp: any) => {
        console.log(resp);
        alert('Data Updated Successfully')
      },
      (err: any) => {
        console.log(err);
      }
    );
  }


}