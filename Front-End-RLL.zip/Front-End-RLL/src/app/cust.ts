export class Cust {
    public cust_ID : number;
    public custName : String;
    public address : String;
    public pincode : number;
    public mobileNo : number;
  custID: number;
constructor(){   
}
}

