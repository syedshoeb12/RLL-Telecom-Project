import { Mgr } from './mgr';

describe('Mgr', () => {
  it('should create an instance', () => {
    expect(new Mgr()).toBeTruthy();
  });
});
