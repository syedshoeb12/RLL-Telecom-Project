import { Component, OnInit } from '@angular/core';
import { MgrService } from '../mgr.service';

@Component({
  selector: 'app-manager',
  templateUrl: './manager.component.html',
  styleUrls: ['./manager.component.css']
})
export class ManagerComponent implements OnInit {

  create : any;

  constructor(private _mgrservice : MgrService){}
  register(create:any){
this._mgrservice.create(create.value).subscribe(

);
alert('Registration Successfull')
  }

  ngOnInit(): void {
  }

}
