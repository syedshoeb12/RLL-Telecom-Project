import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustShowComponent } from './cust-show/cust-show.component';
import { TicketsComponent } from './tickets/tickets.component';
import { CustLoginComponent } from './cust-login/cust-login.component';
import { MgrLoginComponent } from './mgr-login/mgr-login.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { EngrLoginComponent } from './engr-login/engr-login.component';
import { CustDashboardComponent } from './cust-dashboard/cust-dashboard.component';
import { MgrDashboardComponent } from './mgr-dashboard/mgr-dashboard.component';
import { EngrDashboardComponent } from './engr-dashboard/engr-dashboard.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AdminShowComponent } from './admin-show/admin-show.component';
import { MgrShowComponent } from './mgr-show/mgr-show.component';
import { EngrShowComponent } from './engr-show/engr-show.component';
import { HomePageComponent } from './home-page/home-page.component';
import { TicketRaiseComponent } from './ticket-raise/ticket-raise.component';
import { ManagerticketsComponent } from './managertickets/managertickets.component';
import { EngineerticketsComponent } from './engineertickets/engineertickets.component';
import { CustomerticketsComponent } from './customertickets/customertickets.component';
import { CustomerComponent } from './customer/customer.component';
import { ManagerComponent } from './manager/manager.component';
import { EngineerComponent } from './engineer/engineer.component';
import { SearchdeleteComponent } from './searchdelete/searchdelete.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { UpdateManagerComponent } from './update-manager/update-manager.component';
import { UpdateEngineerComponent } from './update-engineer/update-engineer.component';
import { Homepage1Component } from './homepage1/homepage1.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { RegistrationComponent } from './registration/registration.component';
import { RegistrationcustomerComponent } from './registrationcustomer/registrationcustomer.component';
import { RegistrationmanagerComponent } from './registrationmanager/registrationmanager.component';
import { TeammenbersComponent } from './teammenbers/teammenbers.component';
import { LocationComponent } from './location/location.component';



const appRoutes : Routes = [
  {path:'',component:Homepage1Component},
  {path:'location',component:LocationComponent},
  {path:'teammenbers',component:TeammenbersComponent},
  {path:'aboutus',component:AboutusComponent},
  {path:'updateCustomer',component:UpdateCustomerComponent},
  {path:'registration',component:RegistrationComponent},
  {path:'registrationmanager',component: RegistrationmanagerComponent},
  {path:'registrationcustomer',component: RegistrationcustomerComponent},
  {path:'homepage',component:HomePageComponent},
  {path:'custLogin',component:CustLoginComponent},
  {path:'adminLogin',component:AdminLoginComponent},
  {path:'mgrLogin',component:MgrLoginComponent},
  {path:'engrLogin',component:EngrLoginComponent},
  {path:'custdashboard',component:CustDashboardComponent},
  {path:'engrdashBoard',component:EngrDashboardComponent},
  {path:'mgrdashBoard',component:MgrDashboardComponent},
  
  {path:'admindashboard',component:AdminDashboardComponent,
  children:[
    {path:'showtickets',component:TicketsComponent,outlet:'mphasis'},
    {path:'updateCustomer',component:UpdateCustomerComponent,outlet:'mphasis'},
    {path:'updatemanager',component:UpdateManagerComponent,outlet:'mphasis'},
    {path:'updateengineer',component:UpdateEngineerComponent ,outlet:'mphasis'},
  ]
},

{path:'custdashboard',component:CustDashboardComponent,
children:[
  {path:'showtickets',component:TicketsComponent,outlet:'mphasis'},
  {path:'addtickets',component:TicketRaiseComponent ,outlet:'mphasis'},
{path:'showCustomerTickets',component:CustomerticketsComponent ,outlet:'mphasis'},
{path:'updateCustomer',component: UpdateCustomerComponent,outlet:'mphasis'},
]

},

{path:'engrdashBoard',component:EngrDashboardComponent,
children:[
  {path:'showtickets',component:TicketsComponent,outlet:'mphasis'},
  {path:'showEngineerTickets',component:EngineerticketsComponent,outlet:'mphasis'},
  {path:'updateticket',component: TicketsComponent,outlet:'mphasis'},
  {path:'updateengineer',component:UpdateEngineerComponent,outlet:'mphasis'},
]
},

{path:'mgrdashBoard',component:MgrDashboardComponent,
children:[
  {path:'showtickets',component:TicketsComponent,outlet:'mphasis'},
  {path:'showManagerTickets',component:ManagerticketsComponent,outlet:'mphasis'},
  {path:'updateengineer',component:UpdateEngineerComponent ,outlet:'mphasis'},
  {path:'updateCustomer',component: UpdateCustomerComponent,outlet:'mphasis'},
]
},
{path:'custLogin',component:CustLoginComponent,
children:[
  {path:'create',component:CustomerComponent,outlet:'mphasis'},
  {path:'updateCustomer',component:CustShowComponent,outlet:'mphasis'},
 
]
},
{path:'mgrLogin',component:MgrLoginComponent,
children:[
  {path:'create',component:ManagerComponent,outlet:'mphasis'},
]},
{path:'engrLogin',component:EngrLoginComponent,
children:[
  {path:'create',component:EngineerComponent,outlet:'mphasis'},
]},


];

@NgModule({
  declarations: [
    AppComponent,
    CustShowComponent,
    TicketsComponent,
    CustLoginComponent,
    MgrLoginComponent,
    AdminLoginComponent,
    EngrLoginComponent,
    CustDashboardComponent,
    MgrDashboardComponent,
    EngrDashboardComponent,
    AdminDashboardComponent,
    AdminShowComponent,
    MgrShowComponent,
    EngrShowComponent,
    HomePageComponent,
    TicketRaiseComponent,
    ManagerticketsComponent,
    EngineerticketsComponent,
    CustomerticketsComponent,
    CustomerComponent,
    ManagerComponent,
    EngineerComponent,
    SearchdeleteComponent,
    UpdateCustomerComponent,
    UpdateManagerComponent,
    UpdateEngineerComponent,
    Homepage1Component,
    AboutusComponent,
    RegistrationComponent,
    RegistrationcustomerComponent,
    RegistrationmanagerComponent,
    TeammenbersComponent,
    LocationComponent,

  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes),
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }


