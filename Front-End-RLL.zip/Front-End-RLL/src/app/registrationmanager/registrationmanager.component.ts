import { Component, OnInit } from '@angular/core';
import { MgrService } from '../mgr.service';

@Component({
  selector: 'app-registrationmanager',
  templateUrl: './registrationmanager.component.html',
  styleUrls: ['./registrationmanager.component.css']
})
export class RegistrationmanagerComponent implements OnInit {
create :any;
  constructor(private _mgrservice : MgrService){}
  register(create:any){
this._mgrservice.create(create.value).subscribe();

  }

  ngOnInit(): void {
  }

}