import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { Cust } from './cust';

@Injectable({
  providedIn: 'root'
})
export class CustService {
  

  constructor(private _http: HttpClient) { }

  showCust(): Observable<Cust []> {
    return this._http.get<Cust[]>("http://localhost:8087/customers")
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }



public updateCustomer(customer: any) {
  return this._http.put("http://localhost:8087/customers",customer);
}

  public create(cust: any){
    return this._http.post("http://localhost:8087/customers",cust)
  }
  public deleteUser(cust_ID: number){
   return this._http.delete(`http://localhost:8087/customers/${cust_ID}`);
  }
  searchCustomer(cid : number): Observable<Cust> {
    return this._http.get<Cust>("http://localhost:8087/customers/"+cid)
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }

}


