import { Component, OnInit } from '@angular/core';

import { CustService } from '../cust-service.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  create : any;

  constructor(private _custService : CustService){}
  register(create:any){
this._custService.create(create.value).subscribe(

);
alert('Registration Successfull')
  }

  ngOnInit(): void {
  }

}
