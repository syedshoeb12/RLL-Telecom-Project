export class Admin {

    public admn_ID:number;
    public admnName:string;
    public email:string;
    public password:string;

}
