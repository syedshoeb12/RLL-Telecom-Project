import { Component, OnInit } from '@angular/core';
import { Subscriber } from 'rxjs';
import { Cust } from '../cust';
import { CustService } from '../cust-service.service';


@Component({
  selector: 'app-cust-show',
  templateUrl: './cust-show.component.html',
  styleUrls: ['./cust-show.component.css']
})
export class CustShowComponent implements OnInit {
cust_ID:number;
  cust : Cust[];
  customerToUpdate: any;
  constructor(public _custService : CustService) {
    this._custService.showCust().subscribe({
      next: rs =>{
        this.cust = rs;
      }
    })
   }

 
 
  ngOnInit(): void {
  }
  
  public delteUser(cust_ID:number){
   
    this._custService.deleteUser(cust_ID).subscribe();
 
   return location.reload();
   }

  edit(customer: any){
    this.customerToUpdate = customer;
  }

  updateCustomer(){
    this._custService.updateCustomer(this.customerToUpdate).subscribe(
      (resp: any) => {
        console.log(resp);
      },
      (err: any) => {
        console.log(err);
      }
    );
  }


}


