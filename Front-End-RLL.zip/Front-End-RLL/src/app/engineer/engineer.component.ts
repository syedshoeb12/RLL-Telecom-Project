import { Component, OnInit } from '@angular/core';
import { EngrService } from '../engr.service';

@Component({
  selector: 'app-engineer',
  templateUrl: './engineer.component.html',
  styleUrls: ['./engineer.component.css']
})
export class EngineerComponent implements OnInit {
  create : any;

  constructor(private _engrservice : EngrService){}
  register(create:any){
this._engrservice.create(create.value).subscribe(

);
alert('Registration Successfull')
  }

  ngOnInit(): void {
  }

}
