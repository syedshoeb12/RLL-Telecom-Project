import { Tickets } from './tickets';

describe('Tickets', () => {
  it('should create an instance', () => {
    expect(new Tickets()).toBeTruthy();
  });
});
