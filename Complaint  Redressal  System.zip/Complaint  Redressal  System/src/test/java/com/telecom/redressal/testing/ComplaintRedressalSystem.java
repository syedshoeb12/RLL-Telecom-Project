package com.telecom.redressal.testing;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


import com.telecom.redressal.Model.*;

import com.telecom.redressal.Repository.*;

@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
class ComplaintRedressalSystem {

	@Autowired
	CustRepository customerRepo;
	@Autowired
	EngrRepository engineerRepo;
	@Autowired
	MgrRepository managerRepo;
	@Autowired
	TicketRepository ticketRepo;
	@Autowired
	AdminRepository adminRepo;

	//Junit for customers table
	@Test
	@Order(1)
	public void testCreate() {
			
			Customer m = new Customer();
			m.setCust_ID(1);
			m.setCustName("jhon");
			m.setAddress("mumbai");
			m.setMobileNo(7358515746l);
			m.setPincode(600071);
			Customer m1=customerRepo.save(m);
			assertNotNull(m1);
			
		}
	
		@Test
		@Order(2)
		public void testReadAll() {
    		java.util.List<Customer> list =   customerRepo.findAll();
    		assertThat(list).size().isGreaterThan(0);
    		
    	}
		
		@Test
		@Order(3)
		public void testSingleProduct() {
			Customer customer = customerRepo.findById(1).get();
			assertEquals(600071,customer.getPincode());
		}
		
		@Test
		@Order(4)
		public void testUpdate() {
			Customer m = customerRepo.findById(1).get();
			m.setPincode(600072);
			customerRepo.save(m);
			assertNotEquals(600071,customerRepo.findById(1).get().getPincode());
		}
		
		@Test
		@Order(5)
		public void testDelete() {
			customerRepo.deleteById(2);
			assertThat(customerRepo.existsById(2)).isFalse();
		}
		
		
		// Junit for engineers table
		@Test
		@Order(1)
		public void testCreate1() {
				
				Engr m = new Engr();
				m.setENGR_ID(101);
				m.setENGRNAME("clark");
				m.setMOBILENO(2333873000l);
				m.setPINCODE(200071);
				Engr m1=engineerRepo.save(m);
				assertNotNull(m1);
				
			}
		
			@Test
			@Order(2)
			public void testReadAll1() {
	    		java.util.List<Engr> list =   engineerRepo.findAll();
	    		assertThat(list).size().isGreaterThan(0);
	    		
	    	}
			
			@Test
			@Order(3)
			public void testSingleProduct1() {
				Engr engineer = engineerRepo.findById(101).get();
				assertEquals(200071,engineer.getPINCODE());
			}
			
			@Test
			@Order(4)
			public void testUpdate1() {
				Engr m = engineerRepo.findById(101).get();
				m.setPINCODE(200077);
				engineerRepo.save(m);
				assertNotEquals(200071,engineerRepo.findById(101).get().getPINCODE());
			}
			
			@Test
			@Order(5)
			public void testDelete1() {
				engineerRepo.deleteById(102);
				assertThat(engineerRepo.existsById(102)).isFalse();
			}
	
			
			//Junit for Manager table
			
			@Test
			@Order(1)
			public void testCreate2() {
					
					Mgr m = new Mgr();
					m.setMGR_ID(201);
					m.setMGRNAME("williams");
					m.setMOBILENO(2333873000l);
					m.setPINCODE(200071);
					Mgr m1=managerRepo.save(m);
					assertNotNull(m1);
					
				}
			
				@Test
				@Order(2)
				public void testReadAll2() {
		    		java.util.List<Mgr> list =   managerRepo.findAll();
		    		assertThat(list).size().isGreaterThan(0);
		    		
		    	}
				
				@Test
				@Order(3)
				public void testSingleProduct2() {
					Mgr manager = managerRepo.findById(201).get();
					assertEquals(200071,manager.getPINCODE());
				}
				
				@Test
				@Order(4)
				public void testUpdate2() {
					Mgr m = managerRepo.findById(201).get();
					m.setPINCODE(560002);
					managerRepo.save(m);
					assertNotEquals(200071,managerRepo.findById(201).get().getPINCODE());
				}
				
				@Test
				@Order(5)
				public void testDelete2() {
					managerRepo.deleteById(202);
					assertThat(managerRepo.existsById(202)).isFalse();
				}
				
				
				//junit for Ticket table
				@Test
				@Order(1)
				public void testCreate3() {
						
						Ticket m = new Ticket();
						m.setCust_ID(1);
						m.setMgr_ID(201);
						m.setEngr_ID(101);
						m.setPincode(600071);
						m.setStatus("Resolved");
						m.setT_NO(112);
						m.setComplaint("Neither make nor receive calls");
						Ticket m1=ticketRepo.save(m);
						assertNotNull(m1);
						
					}
				
					@Test
					@Order(2)
					public void testReadAll3() {
			    		java.util.List<Ticket> list =   ticketRepo.findAll();
			    		assertThat(list).size().isGreaterThan(0);
			    		
			    	}
					
					@Test
					@Order(3)
					public void testSingleProduct3() {
						Ticket ticket = ticketRepo.findById(112).get();
						assertEquals(600071,ticket.getPincode());
					}
					
					@Test
					@Order(4)
					public void testUpdate3() {
						Ticket m = ticketRepo.findById(112).get();
						m.setPincode(600071);
						ticketRepo.save(m);
						assertNotEquals(200071,ticketRepo.findById(112).get().getPincode());
					}
					
					@Test
					@Order(5)
					public void testDelete3() {
						ticketRepo.deleteById(1001);
						assertThat(ticketRepo.existsById(1001)).isFalse();
					}
					
					
				//Junit for Admin table	
					@Test
					@Order(1)
					public void testCreate4() {
							
							Admin m = new Admin();
							m.setAdmn_ID(100);
							m.setAdmnName("Syed");
							m.setEmail("syed@gmail.com");
							m.setPassword("Telecom");
							Admin m1=adminRepo.save(m);
							assertNotNull(m1);
							
						}
					
						@Test
						@Order(2)
						public void testReadAll4() {
				    		java.util.List<Admin> list =   adminRepo.findAll();
				    		assertThat(list).size().isGreaterThan(0);
				    		
				    	}
						
						@Test
						@Order(3)
						public void testSingleProduct4() {
							Admin admin = adminRepo.findById(100).get();
							assertEquals("syed@gmail.com",admin.getEmail());
						}
						
						@Test
						@Order(4)
						public void testUpdate4() {
							Admin admin = adminRepo.findById(100).get();
							admin.setEmail("syed@gmail.com");
							adminRepo.save(admin);
							assertNotEquals("ash@gmail.com",adminRepo.findById(100).get().getEmail());
						}
										
                    }
